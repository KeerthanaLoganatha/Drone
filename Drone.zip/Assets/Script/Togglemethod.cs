using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Togglemethod : MonoBehaviour
{
   public GameObject dronecomponent; 
   private bool isVisible = true;
   public void Toggle()
   {
    if(isVisible)
    {
        dronecomponent.SetActive(false);
        isVisible = false;
        
    }
    else
    {
         dronecomponent.SetActive(true);
        isVisible = true;
    }
   }
}
